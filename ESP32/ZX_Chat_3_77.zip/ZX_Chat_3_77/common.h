#ifndef COMMON_H_
#define COMMON_H_
#include "Arduino.h"

#define uromVersion "3.80"
#define SwVersion "3.85"

#define debug
#define zxspectrum


#endif //COMMON_H_
