#ifndef COMMON_H_
#define COMMON_H_
#include "Arduino.h"

#define uromVersion "3.76"
#define SwVersion "3.82"

#define debug
#define zxspectrum


#endif //COMMON_H_
