#ifndef COMMON_H_
#define COMMON_H_
#include "Arduino.h"

#define uromVersion "3.74"
#define SwVersion "3.81"

//#define debug
#define zxspectrum


#endif //COMMON_H_
